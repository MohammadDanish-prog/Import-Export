import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Award, ShieldCheck } from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { CERTIFICATIONS, QUALITY_STEPS } from "@/lib/site-data";

// One card in the deck. All cards sit in the exact same spot, stacked on
// top of one another. Each has its "turn" as the scroll progress passes
// its slice of the overall track — until then it just peeks slightly
// behind the cards in front; once its turn ends, it's flung off-screen.
function StackCard({ step, index, total, progress }) {
  const dir = index % 2 === 0 ? 1 : -1;

  // How many "turns" away this card still is from being on top (0 once revealed).
  const waitCount = useTransform(progress, (v) => Math.min(3, Math.max(0, index - v * total)));
  const peekY = useTransform(waitCount, (w) => w * 10);
  const peekScale = useTransform(waitCount, (w) => 1 - w * 0.035);

  // How far past this card's own turn we are (0 -> 1 across its discard window).
  const localProgress = useTransform(progress, (v) => {
    const local = v * total - index;
    if (local <= 0.5) return 0;
    return Math.min(1, (local - 0.5) / 0.5);
  });
  const flyX = useTransform(localProgress, (t) => dir * 260 * t);
  const flyRotate = useTransform(localProgress, (t) => dir * 16 * t);
  const flyOpacity = useTransform(localProgress, (t) => 1 - t);

  return (
    <motion.div
      style={{
        y: peekY,
        x: flyX,
        rotate: flyRotate,
        scale: peekScale,
        opacity: flyOpacity,
        zIndex: total - index,
      }}
      className="absolute inset-0 m-auto h-fit w-full max-w-xl rounded-2xl border border-border bg-card p-5 shadow-elevated sm:rounded-3xl sm:p-7 md:p-8"
    >
      <div className="flex items-center gap-3 sm:gap-4">
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-brand text-sm font-bold text-brand-foreground sm:h-11 sm:w-11 sm:text-base">
          {index + 1}
        </div>
        <div className="text-[10px] font-semibold uppercase tracking-wider text-brand sm:text-xs">
          Step {index + 1} of {total}
        </div>
      </div>
      <h3 className="mt-3 font-display text-lg font-semibold sm:mt-4 sm:text-xl md:text-2xl">
        {step.title}
      </h3>
      <p className="mt-2 max-w-md text-sm text-muted-foreground sm:mt-3 sm:text-base">
        {step.desc}
      </p>
    </motion.div>
  );
}

function CardDeck() {
  const trackRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: trackRef,
    offset: ["start start", "end end"],
  });
  const total = QUALITY_STEPS.length;

  return (
    <div ref={trackRef} className="relative" style={{ height: `${total * 24}vh` }}>
      {/* Pinned background + card stack — stays fixed in the viewport while
          the track underneath scrolls, only releasing once the deck is done */}
      <div className="sticky top-0 flex h-[86vh] items-center justify-center overflow-hidden bg-background px-4">
        <div className="relative h-[12rem] w-full max-w-xl sm:h-[11rem] md:h-[10rem]">
          {QUALITY_STEPS.map((s, i) => (
            <StackCard key={s.title} step={s} index={i} total={total} progress={scrollYProgress} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default function QualityPage() {
  return (
    <SiteLayout>
      <section className="mx-auto max-w-7xl px-4 pt-2 pb-0 sm:px-6 md:px-10 md:pt-3 md:pb-0.5">
        <div className="text-xs font-semibold uppercase tracking-[0.2em] text-brand">
          Quality assurance
        </div>
        <h1 className="mt-3 font-display text-3xl font-bold sm:text-4xl md:text-5xl">
          Every shipment, audited end-to-end
        </h1>
        <p className="mt-2.5 max-w-2xl text-sm text-muted-foreground sm:text-base">
          A six-stage process ensures consistency, freshness and compliance from the farm gate to
          the destination dock. Scroll to step through it.
        </p>
      </section>

      {/* Card deck — background pinned, cards stacked directly on top of
          each other, discarded one at a time as you scroll */}
      <CardDeck />

      <section className="mx-auto max-w-7xl px-4 py-1 sm:px-6 md:px-10 md:py-2">
        <div className="rounded-3xl border border-border bg-card p-3 sm:p-4 md:p-5">
          <div className="flex items-center gap-3">
            <Award className="h-5 w-5 text-brand sm:h-6 sm:w-6" />
            <h2 className="font-display text-xl font-bold sm:text-2xl">
              Certifications & standards
            </h2>
          </div>
          <p className="mt-2 text-sm text-muted-foreground sm:text-base">
            We operate against globally recognized food safety frameworks.
          </p>
          <div className="mt-3 flex flex-wrap gap-2 sm:gap-2.5">
            {CERTIFICATIONS.map((c, i) => (
              <motion.div
                key={c}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                className="flex items-center gap-2 rounded-full border border-border bg-background px-3 py-1.5 text-xs font-semibold sm:px-4 sm:py-2 sm:text-sm"
              >
                <ShieldCheck className="h-4 w-4 text-brand" /> {c}
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}